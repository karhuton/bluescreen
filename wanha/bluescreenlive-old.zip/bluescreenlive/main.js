
/* TODO
 
 - jwt tokenien expirointi ja fiksumpi sessiohallinta
 - refresh code -nappi + enter ja esc toimimaan code inputissa
 – presenter rooli
 – cookie: muista minut

 */

const express = require('express')
	,jwtParse = require('express-jwt')
	,jwtSign = require('jsonwebtoken')
	,template = require('express-es6-template-engine')
	,bodyParser = require('body-parser')
	,uuid = require('uuid/v4')
	,hex = require('random-hex')
	,moment = require('moment')

const SESSIONS = {}
const REGEX_UUID = /[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}/
const REGEX_ID = /\/([0-9a-fA-F]+)$/

const JWT_SECRET = 'blue-in-the-face-is-the-best-band-ever'

const app = express()

app.engine('html', template);
app.set('views', 'views')
app.set('view engine', 'html')
app.use(express.static('static'))
app.use(jwtParse({ secret: JWT_SECRET, credentialsRequired: false }), function (req, res, next) {
	if ( !req.user ) {
		let user = { id: uuid() }
		let token = jwtSign.sign(user, JWT_SECRET, { expiresIn: '1h' })

		SESSIONS[user.id] = user
		req.user = user
		req.token = token

		console.log("No user - added one: " + user.id)
	}
	next()
})
app.use(bodyParser.raw({ type: 'application/data-url', limit: '5mb' }))
app.use(bodyParser.json())

/***********
 * Routing *
 ***********/

app.get('/', index)
app.post('/upload/*', upload)
app.post('/download/*', download)
app.post('/stop/*', stop)
app.get('/[0-9a-fA-F]+$', index) /* this has to be the lowest priority route */


app.listen(process.env.PORT || 3000, function () {
  console.log('Listening on port ' + (process.env.PORT || 3000))
})



/*************
 * Responses *
 *************/

function hearbeat(req, res, next) {
	res.status(200)
	.end()
}

function index(req, res, next) {
	// user wants a specific session
	let id = getIdFromPath(req.path)
	let viewId = uuid()

	if ( id ) {
		if ( SESSIONS[id] && !moment().isAfter(moment(SESSIONS[id].timestamp).add(30, 'minutes')) ) {
			return res.render('index', {locals: {code: id, viewer: viewId }})
		}
	}

	// create new session (try 100 times to find an unused or an expired session)
	for (let i = 0 ; i < 100 ; i++) {
		let id = hex.generate().replace(/^#/, '')

		if ( !SESSIONS[id] || moment().isAfter(moment(SESSIONS[id].timestamp).add(30, 'minutes')) ) {
			SESSIONS[id] = {
				id: id
				,timestamp: moment()
				,image: null
				,width: null
				,height: null
				,mimetype: null
				,size: null
				,frame: 0
				,viewers: { }
			}
			
			SESSIONS[id].viewers[viewId] = { id: viewId, timestamp: moment()}
			return res.render('index', {locals: {jwt: req.token, code: id, viewer: viewId }});
		}
	}
	
	return res.status(503).render('busy')
}

function upload(req, res, next) {
	let id = getIdFromPath(req.path)

	if ( !SESSIONS[id] ) {
		res.status(404).send("Not found");
		return next()
	}

	if ( moment().isAfter(moment(SESSIONS[id].timestamp).add(30, 'minutes')) ) {
		res.status(419).send("Expired");
		return next()		
	}	

	if ( req.body && req.body.length > 0 ) {
		if ( !req.header('Content-Type') || !req.header('ImageWidth') || !req.header('ImageHeight')) {
			res.status(400).send("Bad request");
			return next()
		}

		SESSIONS[id].mimetype = req.header('Content-Type')
		SESSIONS[id].width = req.header('ImageWidth')
		SESSIONS[id].height = req.header('ImageHeight')
		SESSIONS[id].frame++
		SESSIONS[id].image = req.body
		SESSIONS[id].size = req.body.length
	}

	SESSIONS[id].timestamp = moment()

	let meta = Object.assign({}, SESSIONS[id])
	delete meta.image

	res.status(200)
	.set('Content-Type', 'application/json')
	.set('MetaData', JSON.stringify(meta))
	.send()
	return next()
}

function download(req, res, next) {
	try {
		let id = getIdFromPath(req.path)
		let meta = JSON.parse(req.header('MetaData'))

		if ( !SESSIONS[id] ) {
			res.status(404).send("Not found");
			return next()
		}

		if ( !meta ) {
			res.status(400).send("Bad request");
			return next()		
		}	

		if ( !meta.viewer || !REGEX_UUID.test(meta.viewer) ) {
			res.status(403).send("Forbidden");
			return next()
		}	

		if ( moment().isAfter(moment(SESSIONS[id].timestamp).add(30, 'minutes')) ) {
			res.status(419).send("Expired");
			return next()		
		}	

		if ( !SESSIONS[id].viewers[meta.viewer] ) { SESSIONS[id].viewers[meta.viewer] = { id: meta.viewer } }
		SESSIONS[id].viewers[meta.viewer].timestamp = moment()

		let returnMeta = Object.assign({}, SESSIONS[id])
		delete returnMeta.image

		if ( meta.frame >= returnMeta.frame ) {
			res.status(304)
			.set('MetaData', JSON.stringify(returnMeta))
			.send("Not modified");
			return next()
		}

		if ( !SESSIONS[id].image ) {
			res.status(204)
			.set('MetaData', JSON.stringify(returnMeta))
			.send("No content");
			return next()
		}

		res.status(200)
		.set('Content-Type', SESSIONS[id].mimetype)
		.set('MetaData', JSON.stringify(returnMeta))
		.end(SESSIONS[id].image)
		return next()

	} catch (err) {
		console.error("Failed in download reponse", err)
		res.status(500).send("Fail")
		return next()
	}	
}

function stop(req, res, next) {
	let id = getIdFromPath(req.path)
	let meta = JSON.parse(req.header('MetaData'))

	if ( !SESSIONS[id] ) {
		res.status(404).send("Not found");
		return next()
	}

	if ( !meta ) {
		res.status(400).send("Bad request");
		return next()
	
	}	
	if ( !meta.viewer || !REGEX_UUID.test(meta.viewer) ) {
		res.status(403).send("Forbidden");
		return next()
	}

	SESSIONS[id].timestamp = moment()
	SESSIONS[id].mimetype = null
	SESSIONS[id].width = null
	SESSIONS[id].height = null
	SESSIONS[id].frame = 0
	SESSIONS[id].image = null
	SESSIONS[id].size = null

	res.status(200).send("OK")
	return next()
}

/***********
 * Helpers *
 ***********/


function getIdFromPath(path) {
	if ( path && REGEX_ID.test(path) ) {
		return path.match(REGEX_ID)[1]
	}

	return null
}

setInterval(sessionStatusCheck, 10*1000)

function sessionStatusCheck() {
	let keys = Object.keys(SESSIONS)

	if ( keys.length == 0 ) {
		console.log("No active sessions")
	} else {
		console.log("Active sessions: " + keys.length)

		keys.forEach(function(id){
			let session = SESSIONS[id]
			let expired = moment().isAfter(moment(session.timestamp).add(30, 'minutes'))
			let viewers = Object.keys(session.viewers).length

			console.log("id: " + id + " frame: " + session.frame + (session.image ? " " + session.width + "x" + session.height + " (" + Math.round(session.size/1024) + "kb)" : "") + " timestamp: " + moment(session.timestamp).format('YYYY-MM-DD HH:mm:ss') + (
				expired ? " (expired)" : "" ) + " viewers: " + viewers)

			if (expired) {
				delete SESSIONS[id]
			}
		})
	}
}

