const express = require('express')
	,fileUpload = require('express-fileupload')
	,uuid = require('uuid/v4')
	,convertapi = require('convertapi')('hUTgc5Vgihz2Nj22')
	,template = require('express-es6-template-engine')
	,hex = require('random-hex')
	,moment = require('moment')

var session = require('express-session')
var codes = {}

const app = express()

app.engine('html', template);
app.set('views', 'views')
app.set('view engine', 'html')
app.use(express.static('static'))

app.use(session({ secret: 'cowabungalow', resave: false, saveUninitialized: true, cookie: { maxAge: 31556952000 }})) // 1 year
app.use(fileUpload({
    useTempFiles : true
    ,tempFileDir : require('os').tmpdir()
    ,limits: { filesize: 50*1024*1024 }
}));

app.get('/', index)
app.get('/present', index)
app.post('/upload', upload);


app.listen(process.env.PORT || 3000, function () {
  console.log('Listening on port ' + (process.env.PORT || 3000))
})

function upload(req, res, next) {
	var id = req.query.code

	if ( id && id.match("^[0-9a-zA-Z]+$") ) {
		var rand = uuid()
		if ( !session.uploads ) { session.uploads = {} }

		session.uploads[id] = { original: req.files.file, rand: rand }
		if ( !req.files.file ) {
	        res.status(400)
	        res.send("Add file input")
	        next()
		}
		console.log("Upload file to converter: " + req.files.file.tempFilePath)
		convertapi.convert('png', {
		    File: req.files.file.tempFilePath
		    ,ImageWidth: 1920
	    	,ImageResolutionH: '72'
		    ,ImageResolutionV: '72'
	    	,ScaleImage: 'true'
	    	,ScaleProportions: 'true'
		    ,ScaleIfLarger: 'true'
		    ,FileName: rand + "-" + req.files.file.name
		}).then(function(result) {
			console.log("Got result from converter", result.files)
			var urls = []
			for ( var i = 0 ; i < result.files.length ; i++ ) {
				urls.push(result.files[i].fileInfo.Url)		
			}
			console.log("URLS:", urls)
			res.send(urls.join("\n"))
			next()
		    /*
		    var dir = require('os').tmpdir();
			result.saveFiles(dir).then(function(files){
				session.uploads[id].files = files
				console.log("Files saved to:", files)					
				res.send("Upload done.")
				next()
			});
			*/
		});

	} else {
        res.status(400)
        res.send("Add proper code input")
        next()		
	}
}

function index(req, res, next) {
	var host = req.headers.host.split(":")[0]
	var path = req.path.substr(1)

	if ( host == "present.bluescreen.live" || path == "present" ) {
		if ( path != "present" && path.matches("\/-?[0-9a-fA-F]+") ) {
			var code = path
		} else {
			res.render('present');
		}

	} else {
		var code = "ERROR"
		for (var i = 0 ; i < 1000 ; i++) {
			var code = hex.generate()
			if ( !codes[code] || moment().isAfter(moment(codes[code].timestamp).add(24, 'hours')) ) {
				codes[code] = { timestamp: moment(), code: code }
				break;
			}
		}
		
		res.render('index', {locals: {code: code }});
		console.log(codes)
	} 
  
}