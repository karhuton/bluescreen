/**
 * Blue Screen Live
 *
 * Requires xhttp-json-jwt.js
 */

/*
	TODO:

	upload/donwload uudelleen kirjoitus xhttp-json-jwt versioiksi
	state hallintaa onSessionUpdate tyyppiseen (on state change?)

	pitäiskö tehdä ui main loop joka käy tsekkailemassa tilannetta?
	verkkoyhteydet elää oma elämää
	kuvankaappaus elää omaa elämää

	ui-loop tsekkaa mktä "state" menossa ja tarkastelee
	miten verkko ja kuvakaappaus jaksaa

*/

function init() {	
	onSessionUpdate(hasViewers)
}

function hasViewers(session) {
	if ( !session.viewers ) { return }

	var count = session.viewers.length

	switch(getState()) {
		case STATE.waiting:
		case STATE.connecting:
			if ( count >= 2 ) { setState('recording') }
		case STATE.recording:
			if ( count < 2 ) { setState('waiting') }
		default:
			break;
	}
}

/******************
 * Screen capture *
 ******************/

async function startCapture() {
	try {
		let stream = await navigator.mediaDevices.getDisplayMedia({ 
			video: { cursor: "never" },
			audio: false 
		});

		let video = document.querySelector('#video')
		video.srcObject = stream

		setState('connecting')

	} catch (err) {
		console.error("Screen capture error:", err)

		setState('error')

		return false
	}

	return true
}

async function stopCapture() {
	let video = document.querySelector('#video')
	let tracks = video.srcObject.getTracks();
  	tracks.forEach(track => track.stop());
  	video.srcObject = null;

  	setState('ready')

	stopUpload()  	
}


/****************************
 * Image upload from stream *
 ****************************/

var LAST_UPLOAD_TIME = -1

// Download is delayed a 
const INTERVALS = {
	heartbeat: setInterval(heartbeat, 250)
//	, upload: setInterval(upload, 500)
//	, download: setInterval(download, 500)
}

/**
 * get() keeps JWT token data uptodate – for example when more viewers come in
 */
function hearbeat() {
	get("/hearbeat", null, function(status, token, data) {
		if ( !status ) { console.log("Connection problems ...") }

		switch ( getState() ) {
			case STATE.ready:
			case STATE.connecting:
			case STATE.waiting:
			case STATE.recording:
			case STATE.watching:
			case STATE.error:
			default:
				break;
		}
	})
}

function upload() {
	if ( !getState('connecting', 'waiting', 'recording') ) { return }

	let user = getToken()

	try {
		let id = document.querySelector('#code').innerText
		let video = document.querySelector('#video')
		let viewer = document.querySelector('#viewer').innerText
		let currentViewCount = video.getAttribute('viewers') || 0
		let canvas = captureImageFromVideo(video)
	
		xhttp.setRequestHeader("Content-Type", "application/data-url");
		xhttp.setRequestHeader("MetaData", JSON.stringify({ id: id, viewer: viewer }));

		xhttp.onreadystatechange = function() {
			try {
			    if (this.readyState === XMLHttpRequest.DONE) {
			    	var viewCount = -1
			    	if ( xhttp.getResponseHeader('MetaData') ) {
						let meta = JSON.parse(xhttp.getResponseHeader('MetaData'))
						viewCount = Object.keys(meta.viewers).length
			    		video.setAttribute('viewers', viewCount)
			    	}

			    	if ( this.status === 200) {
				    	if ( viewCount > 1 ) {
				    		setState('recording')
				    	} else {
				    		setState('waiting')
				    	}

				    } else {
				    	console.error("Error uploading data", this)
				    	setState('error')
				    }
				}
			} catch (err) {
				setState('error')
				console.error("Error handling upload response", err)
			}
		}

		let data
		if ( currentViewCount > 0 ) {
			xhttp.setRequestHeader("ImageWidth", canvas.width);
			xhttp.setRequestHeader("ImageHeight", canvas.height);
			data = canvas.toDataURL(ENCODER[QUALITY].type, ENCODER[QUALITY].quality)
		}
		xhttp.send(data)
	} catch (err) {
		setState('error')
		console.error("Image capture and upload failed", err)
	}
}

function stopUpload() {
	try {	
		let id = document.querySelector('#code').innerText
		let viewer = document.querySelector('#viewer').innerText
		let video = document.querySelector('#video')
		video.removeAttribute('viewers')
		let xhttp = new XMLHttpRequest()

		xhttp.open("POST", "/stop/" + id, false)
		xhttp.setRequestHeader("Content-Type", "application/json");
		xhttp.setRequestHeader("MetaData", JSON.stringify({ id: id, viewer: viewer }));
		xhttp.onreadystatechange = function() {
			try {
			    if (this.readyState === XMLHttpRequest.DONE) {
			    	if ( xhttp.getResponseHeader('MetaData') ) {
						let meta = JSON.parse(xhttp.getResponseHeader('MetaData'))
						let viewCount = Object.keys(meta.viewers).length
			    		video.setAttribute('viewers', viewCount)
			    	}

			    	if ( this.status === 200) {
				    	setState('ready')

				    } else {
				    	console.error("Error stopping upload", this)
				    	setState('error')
				    }
				}
			} catch (err) {
				setState('error')
				console.error("Error handling download response", err)
			}
		}

		xhttp.send(JSON.stringify({ id: id, viewer: viewer }))
	} catch (err) {
		setState('ready')
		console.error("Stopping upload failed", err)
	}
}

function captureImageFromVideo(video) {
	let canvas = document.createElement('canvas')
	let scale = (1920 / video.videoWidth)

	if ( video.videoHeight > video.videoWidth ) {
		scale = 1080 / video.videoHeight
	}
	
	if ( scale > 1 ) { scale = 1 }

	let width = Math.round(video.videoWidth * scale)
	let height = Math.round(video.videoHeight * scale)
	canvas.width = width
	canvas.height= height
	video.setAttribute('width', width)
	video.setAttribute('height', height)
	canvas.getContext('2d').drawImage(video, 0,0, width, height)

	return canvas
}

function download() {
	if ( !getState('ready', 'watching', 'notfound') ) { return }

	try {	
		let id = document.querySelector('#code').innerText
		let viewer = document.querySelector('#viewer').innerText
		let video = document.querySelector('#video')
		let display = document.querySelector('#display')
		let frame = display.getAttribute('frame') || 0
		let xhttp = new XMLHttpRequest()
	
		xhttp.open("POST", "/download/" + id, false)
		xhttp.setRequestHeader("Content-Type", "application/json");
		xhttp.setRequestHeader("MetaData", JSON.stringify({ id: id, viewer: viewer }));

		xhttp.onreadystatechange = function() {
			try {
			    if (this.readyState === XMLHttpRequest.DONE) {
			    	if ( xhttp.getResponseHeader('MetaData') ) {
						let meta = JSON.parse(xhttp.getResponseHeader('MetaData'))
						let viewCount = Object.keys(meta.viewers).length
			    		video.setAttribute('viewers', viewCount)
				    	display.setAttribute('frame', meta.frame)
			    	}

			    	if ( this.status === 200) {
				    	display.src = this.response
				    	
				    	setState('watching')

				    } else if ( this.status === 204 ) {
				    	console.log("Waiting for presenter")
				    	setState('ready')
				    }  else if ( this.status === 304 ) {
				    	console.log("Waiting for new content")				    	
				    }  else if ( this.status === 404 ) {
				    	console.log("Nothing found")
				    	setState('notfound')
				    } else {
				    	console.error("Error downloading data", this)
				    	setState('error')
				    }
				}
			} catch (err) {
				setState('error')
				console.error("Error handling download response", err)
			}
		}

		xhttp.send()

	} catch (err) {
		setState('error')
		console.error("Image capture and upload failed", err)
	}
}


/****************
 * State maskin *
 ****************/

const STATE = {
	'ready': true
	,'connecting': true
	,'waiting': true
	,'watching': true
	,'recording': true
	,'notfound': true
	,'error': true
}

var ERROR_TIMEOUT = 10*1000
var ERROR_TIMER = null

function setState(status) {
	let body = document.querySelector("body")

	if ( !STATE[status] ) { throw "Bad state: " + status }
	
	if ( body.classList.contains(status) ) { return status }

	body.classList.add(status);
	
	for ( let [state, notused] of Object.entries(STATE) ) {
		if ( state != status ) {
			body.classList.remove(state);
		}	
	}

	if (status == 'error') {
		ERROR_TIMER = setTimeout(function() { window.location.reload(true); }, ERROR_TIMEOUT)
	} else {
		clearTimeout(ERROR_TIMER)
	}
}

// getState() => current state
// getState('foo', 'bar') => 'foo' or 'bar' if current state, null otherwise
function getState() {
	let body = document.querySelector("body")

	if (arguments.length > 0 ) {
		for ( let i = 0 ; i < arguments.length ; i++ ) {
			if ( body.classList.contains(arguments[i]) ) { return arguments[i] }
		}

		return null

	} else {
		for ( let [state, notused] of Object.entries(STATE) ) {
			if ( body.classList.contains(state) ) { return state }
		}

		throw "Failed to get state from body"
	}
}

/***********
 * Quality *
 ***********/

var QUALITY = 1

const ENCODER = {
	0: { type: 'image/jpeg', quality: 0.5 }
	,1: { type: 'image/jpeg', quality: 0.7 }
	,2: { type: 'image/jpeg', quality: 0.92 }
	,3: { type: 'image/png', quality: 1.0 }
}

