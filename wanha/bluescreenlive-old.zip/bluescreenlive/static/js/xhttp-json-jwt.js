/**
 * Vanilla ES5 JSON get/post with JWT sessions on asynchronous XMLHttpRequest
 *
 */



/**********************
 * Session management *
 **********************

/* Automated single token storage */
var __JWT_TOKEN = JWT_TOKEN_FROM_PAGE_LOAD || null

const __ON_TOKEN_UPDATE = {
//	name: function
}

function onSessionUpdate(callback) {
	__ON_TOKEN_UPDATE[callback.name] = callback
}

function getSession() { return __JWT_TOKEN }

function setSession(token) {
	__JWT_TOKEN = token

	var keys = Object.keys(__ON_TOKEN_UPDATE)

	for ( var i = 0 ; i < keys ; k++ ) {
		var name = keys[i]
		try {
			__ON_TOKEN_UPDATE[name](token)
		} catch (err) {
			console.error("OnSessionUpdate '" + name + "' failed:", err)
		}
	}
}


/***************************
 * XMLHttpRequest wrappers *
 ***************************/

function get(url, data, callback) { getWithToken.apply(null, url, __JWT_TOKEN, data, callback)}

function post(url, data, callback) { postWithToken.apply(null, url, __JWT_TOKEN, data, callback) }


/* Manual token storage */
function getWithToken(url, token, data, callback) { json.apply(null, 'GET', url, token, data, callback) }

function postWithToken(url, token, data, callback) { json.apply(null, 'POST', url, token, data, callback) }


/* Actual work */
function jsonToken(method, url, token, data, callback) { 
	const REGEX_BEARER = /^Bearer\s(.+)$/
	const REGEX_MIME_JSON = /^application\/json;/
	const TOKEN = token
	const XHR = new XMLHttpRequest();

	XHR.open(method, url, true);
	XHR.setRequestHeader('Content-Type', 'application/json; charset=UTF-8');

	XHR.onreadystatechange = function() {
		try {
		    if (this.readyState !== XMLHttpRequest.DONE) { return }

	    	var responseStatus = this.status
	    	var responseData = this.response
	    	var responseToken

	    	if ( XHR.getResponseHeader('Authorization') ) {
	    		var auth = JSON.parse(XHR.getResponseHeader('Authorization'))
	    		
	    		if ( REGEX_BEARER.test(auth) ) {
	    			auth = auth.match(REGEX_BEARER)[1]
	    		}

				responseToken = JSON.parse(auth)
	    	}

	    	if ( REGEX_MIME_JSON.test(XHR.getResponseHeader('Content-Type')) ) {
	    		responseData = JSON.parse( this.response )
	    	}

			callback(responseStatus, responseToken, responseData)

		} catch (err) {
			console.error("XHTTP Error:", err)

			callback()
		}
	}

	xhr.send(JSON.stringify(data));
}	
